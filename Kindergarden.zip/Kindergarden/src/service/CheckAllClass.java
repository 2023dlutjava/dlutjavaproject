package service;


public interface CheckAllClass {
	public void CheckAllClassService();
}
