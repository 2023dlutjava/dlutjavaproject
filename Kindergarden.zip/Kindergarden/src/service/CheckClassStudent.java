package service;


public interface CheckClassStudent {
	public void CheckClassStudentService();
}
