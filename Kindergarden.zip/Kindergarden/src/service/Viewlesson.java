package service;

import java.util.List;

import entity.lesson;

public interface Viewlesson {
	/**
	 * @author 王家豪
	 * 实现打印一个课程表
	 */
	public void prinlesList(List<lesson> lis);
}
