package service;
/**
 * @author 严强强
 */

public interface UpdateStudent {
/*
 * 实现学生的增加和删除
 */
	public void update(int id,int type);
}
