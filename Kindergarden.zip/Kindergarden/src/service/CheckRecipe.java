package service;

public interface CheckRecipe {
	public void CheckRecipeService();
}
