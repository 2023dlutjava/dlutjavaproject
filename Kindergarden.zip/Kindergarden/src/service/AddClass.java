package service;


public interface AddClass {
	public void AddClassService();
	
}
