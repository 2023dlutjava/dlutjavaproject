package service;

public interface UpdateClassInfo {
	public void UpdateClassInfoService();
}
