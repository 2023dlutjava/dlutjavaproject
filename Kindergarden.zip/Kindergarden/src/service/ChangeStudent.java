package service;
/**
 * @author 严强强
 */

public interface ChangeStudent {
	/*
	 * 实现修改学生学籍信息的接口
	 */
	public  void change (int id);
}
