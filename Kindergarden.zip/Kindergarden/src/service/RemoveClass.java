package service;


public interface RemoveClass {
	public void RemoveClassService();
}
