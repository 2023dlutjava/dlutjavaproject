package service.impl;

import java.io.*;
import java.util.*;
import dao.*;
import entity.*;


public class ClassServiceImpl implements AddClass,CheckAllClass,CheckClassStudent,CheckRecipe,RemoveClass,UpdateClassInfo{
	void AddClassService() {
		Scanner input=new Scanner(System.in);
		BaseclassDAOImpl classDAO=new BaseclassDAOImpl();
		List<Baseclass> table0=new List<Baseclass>();
		System.out.print("输入你想增加的班级(小班为1,中班为2,大班为3):");
		String sql,b;
		Object[] param;
		int a=input.nextInt();
		switch(a) {
			case 1:
				sql="select * from classroom where id>=11 and id<=13";
				table0=classDAO.selectclass(sql);
				if(table0.size==3) {
					System.out.println("小班已满");
				}
				else {
					sql="insert into classroom values(?,?,2000);";
					a=""+(10+table0.size+1);
					b="foodfile"+(10+table0.size+1)+".txt";
					param= {a,b};
					classDAO.updatecla(sql,param);
					System.out.println("插入成功");
				}
				break;
			case 2:
				sql="select * from classroom where id>=21 and id<=23";
				table0=classDAO.selectclass(sql);
				if(table0.size==3) {
					System.out.println("中班已满");
				}
				else {
					sql="insert into classroom values(?,?,2500);";
					a=""+(20+table0.size+1);
					b="foodfile"+(20+table0.size+1)+".txt";
					param= {a,b};
					classDAO.updatecla(sql,param);
					System.out.println("插入成功");
				}
				break;
			case 3:
				sql="select * from classroom where id>=31 and id<=33";
				table0=classDAO.selectclass(sql);
				if(table0.size==3) {
					System.out.println("大班已满");
				}
				else {
					sql="insert into classroom values(?,?,3000);";
					a=""+(30+table0.size+1);
					b="foodfile"+(30+table0.size+1)+".txt";
					param= {a,b};
					classDAO.updatecla(sql,param);
					System.out.println("插入成功");
				}
				break;
			default:
				System.out.println("输入非法，请重新输入");
		}
	}
	void RemoveClassService() {
		String sql="drop from classroom where id=?";
		BaseclassDAOImpl classDAO=new BaseclassDAOImpl();
		Scanner input=new Scanner(System.in);
		System.out.print("输入你想删除的班级id:");
		int a=input.nextInt();
		Object[] param= {a};
		int b=classDAO.updatecla(sql,param);
		if(b==0) {
			System.out.println("删除失败，不存在该班级");
		}
		else System.out.println("删除成功");
	}
	void CheckAllClassService() {
		BaseclassDAOImpl classDAO=new BaseclassDAOImpl();
		List<Baseclass> table0=new List<Baseclass>();
		table0=classDAO.getAllclass();
		for(Baseclass baseclass:table0) {
			System.out.println("班级id:" +baseclass.getId()+"    食谱表:"+baseclass.getFoodtext()+"    费用:"+baseclass.getCost();
		}
	}
	void CheckClassStudentService() {
		String sql="select * from student where class=?";
		StudentDAOImpl studentDAO=new StudentDAOImpl();
		List<Student> table0=new List<Student>();
		Scanner input=new Scanner(System.in);
		System.out.print("输入你想查询的班级id:");
		int a=input.nextInt();
		Object[] param= {a};
		table0=studentDAO.selectStudent(sql,param);
		if(table0.size()==0) {
			System.out.println("查无此班或班里没有学生");
			return;
		}
		System.out.println(a+"班里有以下的学生:");
		for(Student student0:table0) {
			System.out.print(student0.getClass()+" ");
		}
	}
	void CheckRecipeService() {
		String sql="select * from classroom where id=?";
		Scanner input=new Scanner(System.in);
		List<Baseclass> table0=new List<Baseclass>();
		BaseclassDAOImpl classDAO=new BaseclassDAOImpl();
		System.out.print("输入你想查询的班级id:");
		int a=input.nextInt();
		Object[] param= {a};
		table0=classDAO.selectclass(sql,param);
		if(table0.size()==0) {
			System.out.println("查无此班");
			return;
		}
		Baseclass baseclass0=table0.get(0);
		try {
			FileReader fr=new FileReader(baseclass0.getFoodtext());
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			while(line!=null) {
				System.out.println(line);
				line=br.readLine();
			}
			br.close();
			fr.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	void UpdateClassInfoService() {
		String sql="select * from classroom where id=?";
		Scanner input=new Scanner(System.in);
		List<Baseclass> table0=new List<Baseclass>();
		BaseclassDAOImpl classDAO=new BaseclassDAOImpl();
		System.out.print("输入你想查询的班级id:");
		int a=input.nextInt();
		Object[] param= {a};
		table0=classDAO.selectclass(sql,param);
		if(table0.size()==0) {
			System.out.println("查无此班");
			return;
		}
		Baseclass baseclass0=table0.get(0);
		System.out.print("输入你想修改的内容(1.班级的序号 2.班级的食谱:");
		int b=input.nextInt();
		switch (b){
			case 1:
				System.out.print("输入想修改成的班级序号:");
				int d=input.nextInt();
				if(d<=10||d>=14&&d<=20||d>=24&&d<=30||d>=34) {
					System.out.println("输入非法");
					return;
				}
				String sql0="update classroom set id=? where id=?";
				Object[] param0= {d,a};
				updatecla(sql,param);
				System.out.println("修改成功");
				break;
			case 2:
				System.out.print("输入想修改成的食谱文件名称:");
				String c=input.next();
				String sql1="update classroom set foodfile=? where id=?";
				Object[] param1= {c,a};
				updatecla(sql,param);
				System.out.println("修改成功");
				break;
			default:
				System.out.println("输入非法");
		}
	}
}
