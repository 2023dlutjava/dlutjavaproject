/**
 * 
 */
/**
 * 
 */
module Kindergarden {
	requires java.sql;
}